# TareaP

TareaPrograAykerHernandez

Este es el primer ejercicio que hicimos en la clase de programacion para empezar a utilizar Java...
